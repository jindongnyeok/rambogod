package com.Sparta.HangHaeBlog.Models;

import lombok.Getter;

@Getter
public class MemoRequestDTO
{
    private String postName;
    private String userName;
    private String postText;
}
